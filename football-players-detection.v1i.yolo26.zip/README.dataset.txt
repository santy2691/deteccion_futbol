# football-players-detection > 2026-01-27 7:05pm
https://universe.roboflow.com/santy-qq3k5/football-players-detection-3zvbc-45ujy

Provided by a Roboflow user
License: CC BY 4.0

Deploy a high-performance football player detection model capable of tracking players, referees, and the ball in real-time. This project provides both a pre-trained RF-DETR and YOLO model for immediate integration into sports analytics pipelines and a robust dataset of 372 annotated images for further fine-tuning and custom match analysis.